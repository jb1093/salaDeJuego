import { Entidades } from './entidades';

describe('Entidades', () => {
  it('should create an instance', () => {
    expect(new Entidades()).toBeTruthy();
  });
});
