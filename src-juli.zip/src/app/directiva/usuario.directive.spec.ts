import { UsuarioDirective } from './usuario.directive';

describe('UsuarioDirective', () => {
  it('should create an instance', () => {
    const directive = new UsuarioDirective();
    expect(directive).toBeTruthy();
  });
});
