import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-juego',
  templateUrl: './error-juego.component.html',
  styleUrls: ['./error-juego.component.css']
})
export class ErrorJuegoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
