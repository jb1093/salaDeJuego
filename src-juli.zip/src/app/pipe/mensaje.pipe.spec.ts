import { MensajePipe } from './mensaje.pipe';

describe('MensajePipe', () => {
  it('create an instance', () => {
    const pipe = new MensajePipe();
    expect(pipe).toBeTruthy();
  });
});
