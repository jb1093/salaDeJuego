export const environment = {
  firebase: {
    projectId: 'saladejuegosald3',
    appId: '1:340871378341:web:f29ac7fd0e6d7c6826644c',
    storageBucket: 'saladejuegosald3.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyCRrCAwuiRuHy8n4IeqIwr1iB-TgH28TSQ',
    authDomain: 'saladejuegosald3.firebaseapp.com',
    messagingSenderId: '340871378341',
    measurementId: 'G-51QNHL52E2',
  },
  production: true
};
