// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'saladejuegosald3',
    appId: '1:340871378341:web:f29ac7fd0e6d7c6826644c',
    storageBucket: 'saladejuegosald3.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyCRrCAwuiRuHy8n4IeqIwr1iB-TgH28TSQ',
    authDomain: 'saladejuegosald3.firebaseapp.com',
    messagingSenderId: '340871378341',
    measurementId: 'G-51QNHL52E2',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
